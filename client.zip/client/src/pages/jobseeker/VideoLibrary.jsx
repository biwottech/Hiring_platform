import React from "react";

const VideoLibrary = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold text-center mb-8">Video Library</h1>
      <div className="max-w-2xl mx-auto">Video Library</div>
    </div>
  );
};

export default VideoLibrary;
