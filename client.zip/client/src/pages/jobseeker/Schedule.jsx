import React from "react";

const Schedule = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold text-center mb-8">Schedule</h1>
      <div className="max-w-2xl mx-auto">Schedule</div>
    </div>
  );
};

export default Schedule;
