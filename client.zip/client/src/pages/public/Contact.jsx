import React from "react";

const Contact = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold text-center mb-8">Contact</h1>
      <div className="max-w-2xl mx-auto">Contact</div>
    </div>
  );
};

export default Contact;
